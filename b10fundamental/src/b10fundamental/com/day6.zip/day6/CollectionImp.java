package b10fundamental.com.day6;

public class CollectionImp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
