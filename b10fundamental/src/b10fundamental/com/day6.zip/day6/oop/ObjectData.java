package b10fundamental.com.day6.oop;

public class ObjectData {
	
	String g = "hai";
	
	public static void main(String[] args) {
		
	}

}
