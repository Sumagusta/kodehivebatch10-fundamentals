package b10fundamental.com.day3.condition.task;

public class Task1 {

	public static void main(String[] args) {

		/* 1. Buatlah kondisi berikut :
		 * 	
		 * Dalam perebutan piala oscar terdapat nominasi dari artis 
		 * yang salah satunya akan bisa memenagkan piala. Untuk bisa memenangkan piala,
		 * harus memenuhi point tertentu yakni :
		 * 
		 *  - poin acting
		 *  - poin gimmick
		 *  - poin drama
		 *  - poin character
		 *  
		 * untuk bisa mendapatkan Piala Oscar rata-rata dari poin diatas harus > 8/10
		 * 
		 * Buatlah kondisi untuk bisa mendapatkan piala berdasarkan poin
		 * 
		 * Gunakan input console untuk input nama artis dan setiap poinnya
		 * 
		 * expected :
			 * Artis : ?
			 * Poin ~
			 * Dapat piala or not ?
		 * */ 

	}

}
