package b10fundamental.com.day3.loop;

public class CaraKerjaSoalPortal {
	
	public static void printData(int loop) {
		System.out.println(loop);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		printData(5);
		
	}

}
