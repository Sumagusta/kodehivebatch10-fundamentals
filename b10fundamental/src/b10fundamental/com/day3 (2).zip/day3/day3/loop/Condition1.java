package b10fundamental.com.day3.loop;

public class Condition1 {

	public static void main(String[] args) {

		

	}

}
