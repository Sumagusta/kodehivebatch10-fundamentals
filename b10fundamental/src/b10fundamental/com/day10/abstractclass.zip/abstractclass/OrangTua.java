package b10fundamental.com.day10.abstractclass;

public abstract class OrangTua {
	
	// concrete method
	public static void harta() {
		System.out.println("Emas");
		System.out.println("Tanah");
	}
	
	// abstract method
	public abstract void bakat();
	
}
