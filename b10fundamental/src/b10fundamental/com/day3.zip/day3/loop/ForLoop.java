package b10fundamental.com.day3.loop;

import java.util.Scanner;

public class ForLoop {

	public static void main(String[] args) {
		
		Scanner scan= new Scanner(System.in);
		
		// gunakan utk loop yang sudah pasti jumlah iterasinya
		
		for (int i = 5; i > 0 ; i--) {
			System.out.println(i);
		}
		
	}
}
