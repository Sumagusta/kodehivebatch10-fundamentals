package b10fundamental.com.day5.bahas;

public class Array1DSize {

	public static void main(String[] args) {

		String[] sayuran = new String[5];
		sayuran[0] = "BROKOLI";
		sayuran[1] = "BROKOLI";
		sayuran[2] = "BROKOLI";
		sayuran[3] = "BROKOLI";
		sayuran[4] = "BROKOLI";

		for (int i = 0; i < sayuran.length; i++) {
			System.out.println(sayuran[i]);
		}

	}

}
