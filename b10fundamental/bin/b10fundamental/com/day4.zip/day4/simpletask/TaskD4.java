package b10fundamental.com.day4.simpletask;

public class TaskD4 {

	public static void main(String[] args) {

		/*1. Terdapat suatu restoran yang awalnya sepi pengunjung
		 * 
		 *  setiap harinya hanya mendapatkan satu pengunjung 
		 *  yang membeli produk senilai 100000
		 * namun pembeli itu baik hati dan selalu memberikan tips 
		 * sebanyak 10000 setiap membeli produk tersebut. 
		 * 
		 * tips dari pembeli ini setiap hari nya dinaikan 1x lipat dari 
		 * harga terakhir+tips di hari sebelumnya
		 * 
		 * jadi berapa pendapatan penjual produk 
		 * jika pembeli tersebut datang 5 hari berturut-turut ?
		 * 
		 * */
		
		

	}

}
