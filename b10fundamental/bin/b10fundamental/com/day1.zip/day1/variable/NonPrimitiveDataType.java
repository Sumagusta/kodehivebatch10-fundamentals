package b10fundamental.com.day1.variable;

public class NonPrimitiveDataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// String
		String data = "kumpulan karakter";
		System.out.println(data);
	}

}
