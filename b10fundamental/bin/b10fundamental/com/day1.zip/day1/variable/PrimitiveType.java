package b10fundamental.com.day1.variable;

public class PrimitiveType {

	public static void main(String[] args) {

		//boolean
		
		boolean a = true;
		Boolean a1 = false;
		
		byte byte1 = -128;
		System.out.println("Max Value dari byte : "+Byte.MAX_VALUE);

		System.out.println("Max value dari short : "+Short.MAX_VALUE);
		
		int int1 = -2147483647;
		Integer int2 = 2147483647;
		System.out.println("Max value dari short : "+Integer.MAX_VALUE);
		
		long long1 = 9223372036854775807l; // tugas
		System.out.println("Max value dari short : "+Long.MAX_VALUE);
		
		char char1 = 'A';
		
		
		
	}

}
