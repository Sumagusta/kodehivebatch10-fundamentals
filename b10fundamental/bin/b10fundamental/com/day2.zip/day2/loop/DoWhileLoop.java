package b10fundamental.com.day2.loop;

public class DoWhileLoop {

	public static void main(String[] args) {

		int i=100;
		int kelipatan = 8;
		do {
			System.out.println(kelipatan);
			kelipatan+=8;
			i++;
		} while (i < 5);

	}

}
