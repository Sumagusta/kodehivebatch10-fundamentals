package b10fundamental.com.day2.variable;

public class Konversi {

	public static void main(String[] args) {

		String angkaString = "8000";
		
		int angkaInteger = 15;
		
		System.out.println(Integer.valueOf(angkaString) * angkaInteger);

	}

}
