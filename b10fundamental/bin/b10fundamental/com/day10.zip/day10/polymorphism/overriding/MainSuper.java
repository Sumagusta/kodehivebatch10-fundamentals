package b10fundamental.com.day10.polymorphism.overriding;

public class MainSuper {
	
	public void bisaDipanggil(){
		System.out.println("Test test");
	}

	public static void main(String[] args) {
		SuperClass sc = new SuperClass();
		sc.buah();
	}
}
