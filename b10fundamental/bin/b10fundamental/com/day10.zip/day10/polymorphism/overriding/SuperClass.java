package b10fundamental.com.day10.polymorphism.overriding;

public class SuperClass {
	
	public void buah() {
		System.out.println("Pisang");
	}

}
